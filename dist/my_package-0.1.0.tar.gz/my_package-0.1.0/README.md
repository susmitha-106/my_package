# My Package

This is an example package to understand the basics of developing your first Python package.

## Installation

```sh
pip install my_package
