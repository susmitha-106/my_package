def foo():
    return "Hello from module1!"
